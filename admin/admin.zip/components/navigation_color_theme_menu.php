<ul class="header_actions pull-left hidden-480 hidden-768">
    <li rel="tooltip" data-placement="bottom" title="Hide/Show main navigation" ><a href="#" class="hide_navigation"><i class="icon-chevron-left"></i></a></li>
    <li rel="tooltip" data-placement="right" title="Change navigation color scheme" class="color_pick navigation_color_pick"><a class="iconic" href="#"><i class="icon-th"></i></a>
        <ul>
            <li><a class="blue" href="#"></a></li>
            <li><a class="light_blue" href="#"></a></li>
            <li><a class="grey" href="#"></a></li>
            <li><a class="dark_grey" href="#"></a></li>
            <li><a class="pink" href="#"></a></li>
            <li><a class="red" href="#"></a></li>
            <li><a class="orange" href="#"></a></li>
            <li><a class="yellow" href="#"></a></li>
            <li><a class="green" href="#"></a></li>
            <li><a class="dark_green" href="#"></a></li>
            <li><a class="turq" href="#"></a></li>
            <li><a class="dark_turq" href="#"></a></li>
            <li><a class="purple" href="#"></a></li>
            <li><a class="violet" href="#"></a></li>
            <li><a class="dark_blue" href="#"></a></li>
            <li><a class="dark_red" href="#"></a></li>
            <li><a class="brown" href="#"></a></li>
            <li><a class="black" href="#"></a></li>
            <a class="dark_navigation" href="#">Dark navigation</a>
        </ul>
    </li>
</ul>