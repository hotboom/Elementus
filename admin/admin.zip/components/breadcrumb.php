<ul class="breadcrumb">
    <li><a href="dashboard.html"><i class="icon-home"></i></a> <span class="divider">/</span></li>
    <li class="active"><a href="#">Dashboard</a></li>
</ul>