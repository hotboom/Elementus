<ul class="header_actions">
    <li rel="tooltip" data-placement="left" title="Header color scheme" class="color_pick header_color_pick hidden-480"><a class="iconic" href="#"><i class="icon-th"></i></a>
        <ul>
            <li><a class="blue set_color" href="#"></a></li>
            <li><a class="light_blue set_color" href="#"></a></li>
            <li><a class="grey set_color" href="#"></a></li>
            <li><a class="dark_grey set_color" href="#"></a></li>
            <li><a class="pink set_color" href="#"></a></li>
            <li><a class="red set_color" href="#"></a></li>
            <li><a class="orange set_color" href="#"></a></li>
            <li><a class="yellow set_color" href="#"></a></li>
            <li><a class="green set_color" href="#"></a></li>
            <li><a class="dark_green set_color" href="#"></a></li>
            <li><a class="turq set_color" href="#"></a></li>
            <li><a class="dark_turq set_color" href="#"></a></li>
            <li><a class="purple set_color" href="#"></a></li>
            <li><a class="violet set_color" href="#"></a></li>
            <li><a class="dark_blue set_color" href="#"></a></li>
            <li><a class="dark_red set_color" href="#"></a></li>
            <li><a class="brown set_color" href="#"></a></li>
            <li><a class="black set_color" href="#"></a></li>
        </ul>
    </li>
    <li rel="tooltip" data-placement="bottom" title="2 new messages" class="hidden-480 messages"><a class="iconic" href="#"><i class="icon-envelope-alt"></i> 2</a>
        <ul class="dropdown-menu pull-right messages_dropdown">
            <li>
                <a href="#">
                    <img src="demo/avatar_06.png" alt="">
                    <div class="details">
                        <div class="name">Jane Doe</div>
                        <div class="message">
                            Lorem ipsum Commodo quis nisi...
                        </div>
                    </div>
                </a>
            </li>
            <li>
                <a href="#">
                    <img src="demo/avatar_05.png" alt="">
                    <div class="details">
                        <div class="name">Jane Doe</div>
                        <div class="message">
                            Lorem ipsum Commodo quis nisi...
                        </div>
                    </div>
                </a>
            </li>
            <li>
                <a href="#">
                    <img src="demo/avatar_04.png" alt="">
                    <div class="details">
                        <div class="name">Jane Doe</div>
                        <div class="message">
                            Lorem ipsum Commodo quis nisi...
                        </div>
                    </div>
                </a>
            </li>
            <li>
                <a href="#">
                    <img src="demo/avatar_05.png" alt="">
                    <div class="details">
                        <div class="name">Jane Doe</div>
                        <div class="message">
                            Lorem ipsum Commodo quis nisi...
                        </div>
                    </div>
                </a>
            </li>
            <li>
                <a href="#">
                    <img src="demo/avatar_06.png" alt="">
                    <div class="details">
                        <div class="name">Jane Doe</div>
                        <div class="message">
                            Lorem ipsum Commodo quis nisi...
                        </div>
                    </div>
                </a>
            </li>
            <a href="#" class="btn btn-block blue align_left"><span>Messages center</span></a>
        </ul>
    </li>
    <li class="dropdown"><a href="#"><img src="demo/avatar_06.png" alt="User image" class="avatar"> Bernad Delic <i class="icon-angle-down"></i></a>
        <ul>
            <li><a href="#"><i class="icon-cog"></i> User options</a></li>
            <li><a href="#"><i class="icon-inbox"></i> Messages</a></li>
            <li><a href="#"><i class="icon-user"></i> Friends</a></li>
            <li><a href="#"><i class="icon-remove"></i> Logout</a></li>
        </ul>
    </li>
    <li><a href="#"><i class="icon-signout"></i> <span class="hidden-768 hidden-480">Logout</span></a></li>
    <li class="responsive_menu"><a class="iconic" href="#"><i class="icon-reorder"></i></a></li>
</ul>