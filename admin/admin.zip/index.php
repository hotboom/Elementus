<? include("../core/init.php");?>
<? include("header.php"); ?>
            <div class="statistic clearfix">
                <div class="current_page pull-left">
                    <span><i class="icon-laptop"></i> Типы элементов</span>
                </div>
            </div>
            <ul class="types">
                <?
                function treeTypes($parent_id=0,$class='types'){
                $types=Elements::getTypes(array('parent'=>$parent_id));
                if(empty($types)) return false;

                if($parent_id==0) echo '<ul class="'.$class.'">';
                    else echo '<ul>';
                        foreach($types as $type){
                        echo '<li><a href="#/type/'.$type['id'].'">'.$type['name'].'</a>';
                            treeTypes($type['id']);
                            echo '</li>';
                        }
                        echo '</ul>';
                    return true;
                    }
                    treeTypes(0);
                ?>
            </ul>
<? include("footer.php"); ?>
